## python script:
                    
                    find area of below shape:

 ['circle','cone','cube','cuboid','droplet','ellipse','hemisphere','hexagonal_pyramid',
        'parallelogram','pentagonal_prism','polygon','rectangle','rectangular_prism',
        'right_triangle','ring','sphere','squre','triangle','triangular_prism'] 


# -- example code --

from pyarea import *

area=circle.area(value)
print("area:",area) 

# -- example code --

from pyarea import square

area=square.area(value)
print("area:",area) 

## --important--
# --to install in local Machine--(windows)

# pip install .\dist\pyarea-1.0.0.tar.gz   